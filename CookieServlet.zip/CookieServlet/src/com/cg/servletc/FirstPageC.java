package com.cg.servletc;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/FirstPageC")
public class FirstPageC extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init(ServletConfig config) throws ServletException {
		
	}

	public void destroy() {
		
	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<head>");
		out.println("<title>First Page</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<div align='center'>");
		out.println("<form name='Pageone' action='SecondPageC' method='post'>");
		out.println("<tr>");
		out.println("<td>Firstname:-</td>");
		out.println("<td><input type='text' name='firstName'><br></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td>Lastname:-</td>");
		out.println("<td><input type='text' name='lastName'><br></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td><input type='submit' name='submit'></td>");
		out.println("</tr>");
		out.println("</form>");
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");
	}

}
