package com.cg.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/ForthPageSM")
public class ForthPageSM extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String phone=request.getParameter("phone");
		String email=request.getParameter("email");
		HttpSession session = request.getSession(false);
		if(session!=null) {
		String firstName=(String) session.getAttribute("firstName");
		String lastName=(String) session.getAttribute("lastName");
		String city=(String) session.getAttribute("city");
		String state=(String) session.getAttribute("state");
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<head>");
		out.println("<title>First Page</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<div align='center'>");
		out.println("<form name='Pagetwo' action='#' method='post'>");
		out.println("<tr>");
		out.println("<td>Firstname:-"+firstName);
		out.println("<br></tr>");
		out.println("<tr>");
		out.println("<td>Lastname:-"+lastName);
		out.println("<br></tr>");
		out.println("<tr>");
		out.println("<td>City:-"+city);
		out.println("<br></tr>");
		out.println("<tr>");
		out.println("<td>State:-"+state);
		out.println("<br></tr>");
		out.println("<tr>");
		out.println("<td>Phone:-"+phone);
		out.println("<br></tr>");
		out.println("<tr>");
		out.println("<td>Email:-"+email);
		out.println("<br></tr>");
		out.println("</form>");
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");
		}
	}

}
