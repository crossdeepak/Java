package com.cg.servleth;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ThirdPageH")
public class ThirdPageH extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		request.setAttribute("city", city);
		request.setAttribute("state", state);
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<head>");
		out.println("<title>First Page</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<div align='center'>");
		out.println("<form name='Pagetwo' action='ForthPageH' method='post'>");
		out.println("<tr>");
		out.println("<td>Firstname:-"+firstName);
		out.println("<br></tr>");
		out.println("<tr>");
		out.println("<td>Lastname:-"+lastName);
		out.println("<br></tr>");
		out.println("<tr>");
		out.println("<td>City:-"+city);
		out.println("<br></tr>");
		out.println("<tr>");
		out.println("<td>State:-"+state);
		out.println("<br></tr>");
		out.println("<tr>");
		out.println("<td>Phone:-</td>");
		out.println("<td><input type='text' name='phone'><br></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td>Email:-</td>");
		out.println("<td><input type='text' name='email'><br></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td><input type='hidden' name='firstName' value="+firstName+"><br></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td><input type='hidden' name='lastName' value="+lastName+"><br></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td><input type='hidden' name='city' value="+city+"><br></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td><input type='hidden' name='state' value="+state+"><br></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td><input type='submit' name='submit'></td>");
		out.println("</tr>");
		out.println("</form>");
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");
	}

}
