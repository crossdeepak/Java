package com.cg.pay.main;

import com.cg.pay.beans.Associate;
import com.cg.pay.beans.BankDetails;
import com.cg.pay.beans.Salary;
import com.cg.pay.services.PayrollServicesImpl;

public class MainClass {

	public static void main(String[] args) {	
	
		PayrollServicesImpl payrollServices = new PayrollServicesImpl();
		int associateID=payrollServices.acceptAssociateDetails("Deepak", "Muraree", "java", "software engg","PJH123", "chinnu@gmail.com",55000, 35000, 500,600, 23457901,"HDFC", "HDFC1234");
		int associateID1=payrollServices.acceptAssociateDetails("Rahul", "Muraree", "java", "software engg","PJH123", "chinnu@gmail.com",55000, 35000, 500,600, 23457901,"HDFC", "HDFC1234");
		System.out.println(associateID);
		System.out.println(payrollServices.getAssociateDetails(associateID).getFirstName()); 
		System.out.println(associateID1);
		System.out.println(payrollServices.getAssociateDetails(associateID).getSalary().getMonthlyTax());
		System.out.println(payrollServices.calculateNetSalary(associateID));
		
		
}
}

/*String searchFirstName="Deepak";
float searchBasicSalary=20000;
Associate associate = searchAssociate(searchFirstName,searchBasicSalary);
if(associate!=null)
System.out.println(associate.getFirstName()+" "+associate.getSalary().getBasicSalary());
else
	System.out.println("Associate details not found");
}
public static Associate searchAssociate(String firstName, float basicSalary){
	Associate [] associates=new Associate[3];
	associates[0] = new Associate(10003, 700000, "Satish", "Mahajan", "Training", "Sr Con", "100213", "abcd@gmail.com",new Salary(15000, 100, 100, 100, 100, 100, 100, 100, 100, 100, 10000),new BankDetails(1234, "Hdfc", "hdfc001"));
	associates[1] = new Associate(10032, 750000, "Deepak", "Muraree", "Developer", "Analyst", "100233", "abdsf@gmail.com",new Salary(45000, 100, 100, 100, 100, 100, 100, 100, 100, 100, 10000),new BankDetails(1234, "Hdfc", "hdfc001"));
	for(Associate associate:associates)
		if(associate!=null && associate.getFirstName()==firstName && associate.getYearlyInvestmentUnder80C()>50000 && associate.getSalary().getBasicSalary()>15000)
			return associate;
	return null;
}
}	
*/


/*	public static void main(String[] args) {
Associate associate = new Associate(100, 15000, "Deepak", "Muraree", "Training", "Analyst", "hgff111", "akash@gmail.com", new Salary(15000, 10, 10, 10, 10, 10, 10, 10, 10, 900, 1100), new BankDetails(111, "abc", "abc111"));
if(associate.getFirstName()=="Deepak" && associate.getSalary().getBasicSalary()>10000);
System.out.println(associate.getSalary().getBasicSalary());
}
}
*/
	